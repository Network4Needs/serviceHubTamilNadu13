# Nalamini Service Platform Deployment Guide

This guide provides instructions for deploying the Nalamini Service Platform to various cloud platforms.

## Prerequisites

Ensure you have the following environment variables set up in your deployment platform:

- `DATABASE_URL`: Your PostgreSQL database connection string
- `RAZORPAY_KEY_ID`: Your Razorpay API key ID
- `RAZORPAY_KEY_SECRET`: Your Razorpay API key secret
- `NODE_ENV`: Set to "production" for deployment
- `PORT`: The port number (usually set by the platform)

## Option 1: Deploy to Render.com

Render.com provides a straightforward way to deploy Node.js applications.

### Steps:

1. Create a new Web Service on Render.com
2. Connect your GitHub repository
3. Configure the service:
   - **Environment**: Node.js
   - **Build Command**: `npm run build`
   - **Start Command**: `node server.js`
4. Add the environment variables mentioned in Prerequisites
5. Deploy the service

### Debugging Common Issues:

- If you encounter a "Failed to reader docker file" error, try deploying without Docker by selecting Node.js as the environment.
- Ensure your Dockerfile is in the root directory and has proper formatting.
- Check your render.yaml file for any syntax errors.

## Option 2: Deploy to Vercel

Vercel is excellent for Node.js applications and offers seamless deployment.

### Steps:

1. Install the Vercel CLI: `npm i -g vercel`
2. Log in to Vercel: `vercel login`
3. From your project directory, run: `vercel`
4. Follow the prompts to configure your project
5. Set up the environment variables mentioned in Prerequisites

### Configuration:

We've included a `vercel.json` file in the project for Vercel configuration:

```json
{
  "version": 2,
  "builds": [
    {
      "src": "server.js",
      "use": "@vercel/node"
    }
  ],
  "routes": [
    {
      "src": "/(.*)",
      "dest": "server.js"
    }
  ],
  "env": {
    "NODE_ENV": "production"
  }
}
```

## Option 3: Deploy to Heroku

Heroku is a popular platform for Node.js applications.

### Steps:

1. Install the Heroku CLI and log in
2. Create a new app: `heroku create nalamini-service-platform`
3. Add PostgreSQL addon: `heroku addons:create heroku-postgresql:hobby-dev`
4. Set up environment variables:
   ```
   heroku config:set RAZORPAY_KEY_ID=your_key_id
   heroku config:set RAZORPAY_KEY_SECRET=your_key_secret
   heroku config:set NODE_ENV=production
   ```
5. Deploy your app: `git push heroku main`

### Configuration:

We've included a `Procfile` in the project for Heroku configuration:

```
web: node server.js
```

## Database Migration

Before deploying, ensure your database schema is up-to-date by running:

```
npm run db:push
```

## Troubleshooting

### Common Issues and Solutions

#### Render.com "Failed to reader docker file" Error
This error might occur when deploying to Render.com with Docker. Try these solutions:

1. **Switch to Node.js environment**: Update your render.yaml file to use `env: node` instead of `env: docker`.
2. **Check Dockerfile format**: Ensure your Dockerfile has no syntax errors and uses proper formatting.
3. **Use the Web UI**: Instead of using the render.yaml file, try creating the service manually through the Render.com web interface.

#### Database Connection Issues
If your application cannot connect to the database:

1. **Check database URL**: Ensure your `DATABASE_URL` is correctly formatted and includes all necessary components (protocol, username, password, host, port, database name).
2. **Network access**: Make sure your deployment platform has network access to your database. Some platforms require explicit allowlisting of IP addresses.
3. **SSL requirements**: Some database providers require SSL connections. Ensure your connection string includes the necessary SSL parameters.

#### Build Failures
If your application fails to build:

1. **Check build logs**: Look for specific error messages in the build logs.
2. **Node.js version**: Ensure the deployment platform is using a compatible Node.js version (we recommend Node.js 20.x).
3. **Dependencies**: Check if all dependencies are correctly listed in package.json and can be installed.

#### Runtime Errors
If your application builds but fails to run:

1. **Environment variables**: Verify all required environment variables are set.
2. **Port binding**: Make sure your application is binding to the port provided by the platform (usually available via the `PORT` environment variable).
3. **File permissions**: Check if your application has the necessary permissions to read/write files, especially for the uploads directory.

#### Health Check Failures
If the health check fails:

1. **Endpoint availability**: Confirm that the `/api/health` endpoint is implemented and responding correctly.
2. **Timeout issues**: If the health check times out, your application might be taking too long to start.

## Support and Resources

### Deployment Utilities

We've included several utilities to help with deployment:

1. **deploy.sh**: A script to help automate the deployment process for different platforms.
2. **export-to-github.sh**: A script to help export your project to GitHub, which is often required for platforms like Vercel.

### Platform-Specific Resources

- **Render.com**: [Render Documentation](https://render.com/docs)
- **Vercel**: [Vercel Documentation](https://vercel.com/docs)
- **Heroku**: [Heroku Dev Center](https://devcenter.heroku.com/)

If you encounter persistent issues with deployment, consider:

1. Consulting the platform's documentation for specific troubleshooting steps
2. Checking if your database provider has specific connection requirements
3. Reaching out to the platform's support team with detailed error logs
4. Reviewing application logs for runtime errors that might not be visible during deployment