import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function LandingPage() {
  const { user } = useAuth();
  const [, navigate] = useLocation();

  // Redirect if user is already logged in
  useEffect(() => {
    if (user) {
      navigate("/dashboard");
    }
  }, [user, navigate]);

  return (
    <div className="min-h-screen flex flex-col">
      {/* Hero section with modern design */}
      <div className="bg-gradient-to-r from-primary to-primary/80 text-white">
        <div className="container mx-auto px-4 py-12 md:py-16">
          <div className="max-w-5xl mx-auto text-center">
            <div className="inline-block p-2 px-4 bg-white/10 rounded-full mb-4">
              <span className="text-white/90 text-sm font-medium">Tamil Nadu's Premier Service Platform</span>
            </div>
            <h1 className="text-4xl md:text-6xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-white to-white/90">
              Nalamini Service Platform
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-white/90 max-w-3xl mx-auto">
              Connecting communities with essential services across Tamil Nadu
            </p>
          </div>
        </div>
      </div>
      
      {/* Featured Video Section - Central Focus */}
      <div className="py-12 bg-white relative">
        {/* Decorative Elements */}
        <div className="absolute top-0 left-0 w-full overflow-hidden">
          <svg className="absolute top-0 left-0 text-primary/5" width="404" height="404" fill="none" viewBox="0 0 404 404">
            <defs>
              <pattern id="pattern-circles" x="0" y="0" width="20" height="20" patternUnits="userSpaceOnUse">
                <circle cx="10" cy="10" r="4" className="text-gray-200" fill="currentColor" />
              </pattern>
            </defs>
            <rect width="404" height="404" fill="url(#pattern-circles)" />
          </svg>
        </div>
        
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto relative">
            <div className="text-center mb-8">
              <span className="inline-block py-1 px-4 rounded-full text-sm font-medium bg-primary/10 text-primary mb-2">
                Watch & Learn
              </span>
              <h2 className="text-3xl font-bold text-gray-900">See Nalamini in Action</h2>
              <p className="text-lg text-gray-600 mt-2 max-w-3xl mx-auto">
                Our comprehensive platform connects communities with essential services and empowers local businesses
              </p>
            </div>
            
            {/* Video Card with Shadow Effects */}
            <div className="bg-white rounded-xl overflow-hidden shadow-xl border border-gray-100 transform transition-all">
              <div className="relative pb-[56.25%] h-0">
                <iframe 
                  className="absolute top-0 left-0 w-full h-full"
                  src="https://www.youtube.com/embed/I3LlcsCyry8" 
                  title="Nalamini Services Platform Overview"
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                  allowFullScreen
                ></iframe>
              </div>
              
              <div className="p-8 text-center">
                <h3 className="text-2xl font-bold mb-3 text-gray-900">Platform Overview</h3>
                <p className="text-gray-600 mb-6 max-w-3xl mx-auto">
                  Discover how our platform is revolutionizing service delivery throughout Tamil Nadu, connecting customers with service providers and creating new opportunities for local businesses.
                </p>
                
                <a 
                  href="https://www.youtube.com/@Nalamini" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-3 text-red-600 hover:text-red-700 font-medium transition-colors px-6 py-3 rounded-full bg-red-50 hover:bg-red-100"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z"/>
                  </svg>
                  Visit our YouTube channel for more videos
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Features section - Highlighted Services */}
      <div className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-8">Our Services</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-none shadow-md hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="mb-4 bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto">
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <path d="M4 11a9 9 0 0 1 9 9"></path>
                    <path d="M4 4a16 16 0 0 1 16 16"></path>
                    <circle cx="5" cy="19" r="2"></circle>
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2 text-center">Mobile Recharges & Utilities</h3>
                <p className="text-gray-600 text-center">
                  Quick and easy payment for mobile recharges and various utility bills including electricity, water, and gas.
                </p>
              </CardContent>
            </Card>

            <Card className="border-none shadow-md hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="mb-4 bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto">
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <path d="M13.5 1.515a3.5 3.5 0 0 0-3 0L4.929 4.464A3.5 3.5 0 0 0 3.5 7.5v9a3.5 3.5 0 0 0 1.429 3.036l5.571 2.949a3.5 3.5 0 0 0 3 0l5.571-2.949A3.5 3.5 0 0 0 20.5 16.5v-9a3.5 3.5 0 0 0-1.429-3.036L13.5 1.515z"></path>
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2 text-center">Travel Bookings</h3>
                <p className="text-gray-600 text-center">
                  Hassle-free bookings for buses, trains, flights, and hotels with competitive prices and instant confirmations.
                </p>
              </CardContent>
            </Card>

            <Card className="border-none shadow-md hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="mb-4 bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto">
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <path d="m15 12-8.5 8.5c-.83.83-2.17.83-3 0 0 0 0 0 0 0a2.12 2.12 0 0 1 0-3L12 9"></path>
                    <path d="M17.64 15 22 10.64"></path>
                    <path d="m20.91 11.7-1.25-1.25c-.6-.6-.93-1.4-.93-2.25v-.86L16.01 4.6a5.56 5.56 0 0 0-3.94-1.64H9l.92.82A6.18 6.18 0 0 1 12 8.4v1.56l2 2h2.47l2.26 1.91"></path>
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2 text-center">Farm Fresh Products</h3>
                <p className="text-gray-600 text-center">
                  Direct farm-to-consumer grocery products sourced from local farmers for freshness and quality.
                </p>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 mt-8">
            <Card className="border-none shadow-md hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="mb-4 bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto">
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"></path>
                    <path d="m4.93 4.93 4.24 4.24"></path>
                    <path d="m14.83 9.17 4.24-4.24"></path>
                    <path d="m14.83 14.83 4.24 4.24"></path>
                    <path d="m9.17 14.83-4.24 4.24"></path>
                    <circle cx="12" cy="12" r="4"></circle>
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2 text-center">Taxi Services</h3>
                <p className="text-gray-600 text-center">
                  On-demand transportation options including taxis, autos, and intercity travel with trusted drivers.
                </p>
              </CardContent>
            </Card>

            <Card className="border-none shadow-md hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="mb-4 bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto">
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <path d="M9 10h.01"></path>
                    <path d="M15 10h.01"></path>
                    <path d="M12 2a8 8 0 0 0-8 8v12l3-3 2.5 2.5L12 19l2.5 2.5L17 19l3 3V10a8 8 0 0 0-8-8z"></path>
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2 text-center">Equipment Rentals</h3>
                <p className="text-gray-600 text-center">
                  Rent quality equipment for events, construction, farming and more with flexible rental periods.
                </p>
              </CardContent>
            </Card>

            <Card className="border-none shadow-md hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="mb-4 bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto">
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <path d="M21 10V8a1 1 0 0 0-1-1h-1"></path>
                    <path d="M5 7H4a1 1 0 0 0-1 1v2"></path>
                    <path d="M10 16v-1a2 2 0 1 1 4 0v1"></path>
                    <path d="M10 16H6a2 2 0 0 0-2 2"></path>
                    <path d="M18 18a2 2 0 0 0-2-2h-4"></path>
                    <path d="m16.71 13.88.7.71-2.82 2.82"></path>
                    <path d="m14.59 14.59.7.71-2.82 2.82"></path>
                    <path d="M14 7v.01"></path>
                    <path d="M10 7v.01"></path>
                    <path d="M14 3.5v.01"></path>
                    <path d="M10 3.5v.01"></path>
                    <path d="M17.5 6.5c-.5-1.5-3.25-3-5.5-3s-5 1.5-5.5 3c-.87.57-1.5 1.78-1.5 2.5h14c0-.72-.63-1.93-1.5-2.5Z"></path>
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2 text-center">Recycling Service</h3>
                <p className="text-gray-600 text-center">
                  Schedule collection of recyclable materials like plastic, aluminum, copper, and brass. Earn money while helping the environment.
                </p>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 mt-8">
            <Card className="border-none shadow-md hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="mb-4 bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto">
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                    <circle cx="8" cy="21" r="1"></circle>
                    <circle cx="19" cy="21" r="1"></circle>
                    <path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"></path>
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-2 text-center">Local Products Marketplace</h3>
                <p className="text-gray-600 text-center">
                  Discover and purchase quality products manufactured locally by trusted artisans and businesses.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
      
      {/* Login Options - Moved to Third Position */}
      <div className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            {/* Background pattern */}
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-primary/5 to-primary/10 rounded-3xl transform -rotate-1 scale-105"></div>
              
              <div className="relative bg-white p-10 rounded-2xl shadow-xl border border-primary/10">
                <div className="text-center mb-8">
                  <span className="inline-block py-1 px-4 rounded-full text-sm font-medium bg-primary/10 text-primary mb-2">
                    Join Our Community
                  </span>
                  <h2 className="text-3xl font-bold mb-2">Get Started Today</h2>
                  <p className="text-gray-600 max-w-2xl mx-auto">
                    Choose your journey with Nalamini Service Platform and be part of a growing ecosystem that's transforming service delivery across Tamil Nadu
                  </p>
                </div>
                
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <div className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-all border border-gray-100 text-center hover:transform hover:scale-105">
                    <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                        <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                      </svg>
                    </div>
                    <h3 className="font-bold mb-2 text-gray-900">Customer</h3>
                    <p className="text-gray-600 text-sm mb-4">Access all services and enjoy special promotions</p>
                    <Button
                      onClick={() => navigate("/auth")}
                      className="w-full bg-primary text-white hover:bg-primary/90"
                    >
                      Get Started
                    </Button>
                  </div>
                  
                  <div className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-all border border-gray-100 text-center hover:transform hover:scale-105">
                    <div className="bg-blue-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600">
                        <path d="M12 11.5v5"></path>
                        <path d="M3.85 8.73a4 4 0 0 1 4.78-1.82C9.757 7.42 11.372 8 13 8c1.367 0 2.805-.455 3.993-1.166A4 4 0 0 1 20.15 8.25h0a4 4 0 0 1-1.285 3.865C18.539 12.37 17.638 13 15 13a8.54 8.54 0 0 1-4-1.178A8.54 8.54 0 0 0 7 11c-2.323 0-3.483.58-3.865.923A4 4 0 0 1 3.85 8.73Z"></path>
                        <path d="M3.85 17.5a4 4 0 0 1 4.78-1.82C9.757 16.2 11.372 16.78 13 16.78c1.367 0 2.805-.455 3.993-1.166A4 4 0 0 1 20.15 17h0a4 4 0 0 1-1.285 3.864C18.539 21.11 17.638 21.73 15 21.73a8.54 8.54 0 0 1-4-1.178A8.54 8.54 0 0 0 7 19.73c-2.323 0-3.483.58-3.865.923A4 4 0 0 1 2.85 16.5h0Z"></path>
                      </svg>
                    </div>
                    <h3 className="font-bold mb-2 text-gray-900">Service Provider</h3>
                    <p className="text-gray-600 text-sm mb-4">Offer your products and services on our platform</p>
                    <Button
                      variant="outline"
                      onClick={() => navigate("/auth?registerAs=provider")}
                      className="w-full border-blue-600 text-blue-600 hover:bg-blue-50"
                    >
                      Register
                    </Button>
                  </div>
                  
                  <div className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-all border border-gray-100 text-center hover:transform hover:scale-105">
                    <div className="bg-green-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-600">
                        <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                        <path d="M22 21v-2a4 4 0 0 0-3-3.87"></path>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                      </svg>
                    </div>
                    <h3 className="font-bold mb-2 text-gray-900">Manager</h3>
                    <p className="text-gray-600 text-sm mb-4">Join our team and expand our services in your area</p>
                    <Button
                      variant="outline"
                      onClick={() => navigate("/auth?registerAs=manager")}
                      className="w-full border-green-600 text-green-600 hover:bg-green-50"
                    >
                      Apply Now
                    </Button>
                  </div>
                  
                  <div className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-all border border-gray-100 text-center hover:transform hover:scale-105">
                    <div className="bg-gray-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-gray-600">
                        <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"></path>
                        <polyline points="10 17 15 12 10 7"></polyline>
                        <line x1="15" y1="12" x2="3" y2="12"></line>
                      </svg>
                    </div>
                    <h3 className="font-bold mb-2 text-gray-900">Existing User</h3>
                    <p className="text-gray-600 text-sm mb-4">Already have an account? Sign in to access services</p>
                    <Button
                      variant="outline"
                      onClick={() => navigate("/auth")}
                      className="w-full border-gray-600 text-gray-600 hover:bg-gray-50"
                    >
                      Sign In
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Service Provider section */}
      <div className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="bg-primary/5 p-8 rounded-xl border border-primary/20">
              <div className="flex flex-col md:flex-row items-center gap-8">
                <div className="flex-1">
                  <h2 className="text-2xl font-bold mb-4">Become a Service Provider</h2>
                  <p className="text-gray-600 mb-6">
                    Join our platform as a service provider and reach thousands of customers across Tamil Nadu. 
                    We offer a simple registration process, easy payment collection, and comprehensive business tools.
                  </p>
                  <div className="flex flex-wrap gap-3 mb-6">
                    <div className="bg-white px-3 py-1.5 rounded-full text-sm font-medium border shadow-sm">Farmers</div>
                    <div className="bg-white px-3 py-1.5 rounded-full text-sm font-medium border shadow-sm">Manufacturers</div>
                    <div className="bg-white px-3 py-1.5 rounded-full text-sm font-medium border shadow-sm">Travel Agents</div>
                    <div className="bg-white px-3 py-1.5 rounded-full text-sm font-medium border shadow-sm">Taxi Providers</div>
                    <div className="bg-white px-3 py-1.5 rounded-full text-sm font-medium border shadow-sm">Rental Services</div>
                    <div className="bg-white px-3 py-1.5 rounded-full text-sm font-medium border shadow-sm">Recycling Agents</div>
                  </div>
                  <Button 
                    className="bg-primary hover:bg-primary/90"
                    onClick={() => navigate("/auth?registerAs=provider")}
                  >
                    Register Now
                  </Button>
                </div>
                <div className="flex-shrink-0 hidden md:block">
                  <div className="bg-primary/10 w-40 h-40 rounded-full flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                      <path d="M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z"></path>
                      <path d="M13 5v2"></path>
                      <path d="M13 17v2"></path>
                      <path d="M13 11v2"></path>
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* YouTube Video Section */}
      <div className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <div className="text-center mb-10">
              <h2 className="text-3xl font-bold mb-4">Watch & Learn</h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Discover how our platform is transforming service delivery across Tamil Nadu through our video presentations and tutorials.
              </p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-8">
              {/* Main Featured Video */}
              <div className="bg-gray-50 rounded-xl overflow-hidden shadow-lg border border-gray-100">
                <div className="relative pb-[56.25%] h-0">
                  <iframe 
                    className="absolute top-0 left-0 w-full h-full"
                    src="https://www.youtube.com/embed/I3LlcsCyry8" 
                    title="TN Services Platform Overview"
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                    allowFullScreen
                  ></iframe>
                </div>
                <div className="p-4">
                  <h3 className="text-xl font-semibold mb-2">Platform Overview</h3>
                  <p className="text-gray-600">Learn about all the services we offer and how they benefit communities across Tamil Nadu.</p>
                </div>
              </div>
              
              {/* Video Grid */}
              <div className="grid grid-cols-1 gap-4">
                {/* Tutorial Video 1 */}
                <div className="bg-gray-50 rounded-lg overflow-hidden shadow border border-gray-100 flex">
                  <div className="relative w-40 flex-shrink-0">
                    <div className="absolute inset-0 bg-black/5 flex items-center justify-center">
                      <iframe 
                        className="w-full h-full"
                        src="https://www.youtube.com/embed/I3LlcsCyry8" 
                        title="How to Register as Provider"
                        frameBorder="0"
                      ></iframe>
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold mb-1">Provider Registration</h3>
                    <p className="text-sm text-gray-600">Step-by-step guide to register as a service provider.</p>
                  </div>
                </div>
                
                {/* Tutorial Video 2 */}
                <div className="bg-gray-50 rounded-lg overflow-hidden shadow border border-gray-100 flex">
                  <div className="relative w-40 flex-shrink-0">
                    <div className="absolute inset-0 bg-black/5 flex items-center justify-center">
                      <iframe 
                        className="w-full h-full"
                        src="https://www.youtube.com/embed/I3LlcsCyry8" 
                        title="Mobile Recharge Tutorial"
                        frameBorder="0"
                      ></iframe>
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold mb-1">Mobile Recharge Tutorial</h3>
                    <p className="text-sm text-gray-600">How to recharge mobile phones quickly and easily.</p>
                  </div>
                </div>
                
                {/* Tutorial Video 3 */}
                <div className="bg-gray-50 rounded-lg overflow-hidden shadow border border-gray-100 flex">
                  <div className="relative w-40 flex-shrink-0">
                    <div className="absolute inset-0 bg-black/5 flex items-center justify-center">
                      <iframe 
                        className="w-full h-full"
                        src="https://www.youtube.com/embed/I3LlcsCyry8" 
                        title="Farmer Products Marketplace"
                        frameBorder="0"
                      ></iframe>
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold mb-1">Farm Fresh Marketplace</h3>
                    <p className="text-sm text-gray-600">Explore our farm-to-consumer fresh produce marketplace.</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="text-center mt-8">
              <a 
                href="https://www.youtube.com/@Nalamini" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-red-600 hover:text-red-700 font-medium"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z"/>
                </svg>
                Visit our YouTube channel for more videos
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Managerial Associate section */}
      <div className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="bg-blue-50 p-8 rounded-xl border border-blue-200">
              <div className="flex flex-col md:flex-row items-center gap-8">
                <div className="flex-shrink-0 hidden md:block">
                  <div className="bg-blue-100 w-40 h-40 rounded-full flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-blue-600">
                      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
                      <circle cx="9" cy="7" r="4"></circle>
                      <path d="M22 21v-2a4 4 0 0 0-3-3.87"></path>
                      <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                    </svg>
                  </div>
                </div>
                <div className="flex-1">
                  <h2 className="text-2xl font-bold mb-4">Join Our Management Team</h2>
                  <p className="text-gray-600 mb-6">
                    Become part of our managerial structure and help expand our services across Tamil Nadu. We're seeking dedicated individuals to join as Branch Managers, Taluk Managers, and Service Agents.
                  </p>
                  <div className="flex flex-wrap gap-3 mb-6">
                    <div className="bg-white px-3 py-1.5 rounded-full text-sm font-medium border shadow-sm">Branch Managers</div>
                    <div className="bg-white px-3 py-1.5 rounded-full text-sm font-medium border shadow-sm">Taluk Managers</div>
                    <div className="bg-white px-3 py-1.5 rounded-full text-sm font-medium border shadow-sm">Service Agents</div>
                    <div className="bg-white px-3 py-1.5 rounded-full text-sm font-medium border shadow-sm">Pincode Area Coverage</div>
                    <div className="bg-white px-3 py-1.5 rounded-full text-sm font-medium border shadow-sm">Earn Commissions</div>
                  </div>
                  <Button 
                    className="bg-blue-600 hover:bg-blue-700 text-white"
                    onClick={() => navigate("/auth?registerAs=manager")}
                  >
                    Apply Now
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">Nalamini Service Platform</h3>
              <p className="text-gray-400">
                A comprehensive platform that connects service providers with customers across Tamil Nadu.
              </p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Mobile Recharges</li>
                <li>Utility Bill Payments</li>
                <li>Travel Bookings</li>
                <li>Grocery Shopping</li>
                <li>Equipment Rental</li>
                <li>Taxi Services</li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">For Providers</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Registration</li>
                <li>Provider Dashboard</li>
                <li>Payment Collection</li>
                <li>Business Analytics</li>
                <li>Marketing Tools</li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Contact Us</h4>
              <ul className="space-y-2 text-gray-400">
                <li>support@tnservices.com</li>
                <li>+91 1234567890</li>
                <li>Chennai, Tamil Nadu</li>
              </ul>
              <div className="flex gap-4 mt-4">
                <a href="#" className="text-gray-400 hover:text-white">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                  </svg>
                </a>
                <a href="#" className="text-gray-400 hover:text-white">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                    <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                  </svg>
                </a>
                <a href="#" className="text-gray-400 hover:text-white">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"></path>
                  </svg>
                </a>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400 text-sm">
            &copy; {new Date().getFullYear()} Nalamini Service Platform. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}