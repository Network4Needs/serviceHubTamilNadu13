# Nalamini Service Platform

A comprehensive service management platform for Tamil Nadu, India, designed to connect service providers with customers through a hierarchical management structure.

## Features

- Role-based authentication (admin, branch managers, taluk managers, service agents, service providers, customers)
- Mobile recharges and bill payments
- Travel & accommodation bookings
- Equipment rentals
- Taxi services
- Delivery management
- Grocery shopping (B2B & B2C with direct farmer connections)
- Local product marketplace
- Recycling services
- Integrated wallet system
- Commission management
- WhatsApp integration for notifications

## Tech Stack

- **Frontend**: React, TypeScript, TailwindCSS, Shadcn UI
- **Backend**: Node.js, Express
- **Database**: PostgreSQL
- **ORM**: Drizzle
- **API Integration**: Razorpay for payments

## Deployment Options

We've provided multiple deployment options:

1. **Vercel** (Recommended)
   - Easy setup through GitHub integration
   - Good support for full-stack Node.js applications
   - Detailed configuration in `vercel.json`

2. **Render.com**
   - Alternative cloud platform with Node.js support
   - Configuration in `render.yaml`

3. **Heroku**
   - Traditional platform with good PostgreSQL integration
   - Configuration in `Procfile` and `static.json`

4. **Docker**
   - Containerized deployment option
   - Configuration in `Dockerfile` and `docker-compose.yml`

## Getting Started

1. Clone this repository
2. Install dependencies: `npm install`
3. Set up environment variables (see below)
4. Run the development server: `npm run dev`

## Environment Variables

The following environment variables are required:

- `DATABASE_URL`: PostgreSQL connection string
- `RAZORPAY_KEY_ID`: Razorpay API key ID
- `RAZORPAY_KEY_SECRET`: Razorpay API key secret

Optional environment variables:

- `WHATSAPP_PHONE_NUMBER_ID`: For WhatsApp integration
- `WHATSAPP_API_KEY`: For WhatsApp integration
- `RECHARGE_API_KEY`: For recharge service providers
- `SENDGRID_API_KEY`: For email notifications

## Deployment Guide

For detailed deployment instructions, please refer to the [DEPLOYMENT_GUIDE.md](./DEPLOYMENT_GUIDE.md) file.

We've included several utilities to help with deployment:

- `deploy.sh`: Interactive script to guide you through deployment
- `export-to-github.sh`: Script to export the project to GitHub

## Database Migration

Before deploying, run the database migration:

```
npm run db:push
```

## Project Structure

- `/client`: Frontend React application
- `/server`: Backend Express API
- `/shared`: Shared types and schema definitions
- `/uploads`: File uploads directory

## Testing the Application

Use the following test accounts:

- Admin: `admin` / `admin123`
- Customer: `testuser` / `testuser123`
- Farmer: `testfarmer` / `farmer123`

## Support

If you encounter any issues with deployment or usage, please refer to the troubleshooting section in the deployment guide or reach out to the development team.

## License

Proprietary - All rights reserved.